package com.example.dynamicislandpro

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DynamicIslandApp() }
    }
}

@Composable
private fun DynamicIslandApp() {
    val context = LocalContext.current
    var width by remember { mutableFloatStateOf(190f) }
    var height by remember { mutableFloatStateOf(42f) }
    var radius by remember { mutableFloatStateOf(28f) }
    var expandedWidth by remember { mutableFloatStateOf(330f) }
    var animation by remember { mutableStateOf(true) }
    var enabled by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9BE7C1),
            background = Color(0xFF0D0F10),
            surface = Color(0xFF181B1D)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF0D0F10)) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("Dynamic Island Pro", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Настрой свой интерактивный островок", color = Color.LightGray)

                Box(
                    Modifier.fillMaxWidth().height(150.dp)
                        .background(Color(0xFF202426), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.width(width.dp).height(height.dp)
                            .background(Color.Black, RoundedCornerShape(radius.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Rounded.MusicNote, null, tint = Color(0xFF9BE7C1))
                            Box(Modifier.width(42.dp).height(4.dp).background(Color(0xFF55595B), RoundedCornerShape(4.dp)))
                            Icon(Icons.Rounded.GraphicEq, null, tint = Color(0xFF9BE7C1))
                        }
                    }
                }

                SettingSlider("Ширина компактного режима", width, 110f..260f, "dp") { width = it }
                SettingSlider("Высота", height, 30f..76f, "dp") { height = it }
                SettingSlider("Ширина раскрытого режима", expandedWidth, 220f..360f, "dp") { expandedWidth = it }
                SettingSlider("Закругление", radius, 0f..40f, "dp") { radius = it }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF181B1D))) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Плавные анимации", color = Color.White, fontWeight = FontWeight.Medium)
                                Text("Раскрытие и сворачивание", color = Color.Gray, fontSize = 12.sp)
                            }
                            Switch(checked = animation, onCheckedChange = { animation = it })
                        }
                    }
                }

                Button(
                    onClick = {
                        if (!Settings.canDrawOverlays(context)) {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                        } else {
                            val intent = Intent(context, IslandOverlayService::class.java).apply {
                                action = IslandOverlayService.ACTION_START
                                putExtra(IslandOverlayService.EXTRA_WIDTH, width)
                                putExtra(IslandOverlayService.EXTRA_HEIGHT, height)
                                putExtra(IslandOverlayService.EXTRA_RADIUS, radius)
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                            else context.startService(intent)
                            enabled = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9BE7C1), contentColor = Color.Black)
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (enabled) "Островок запущен" else "Включить Dynamic Island")
                }

                OutlinedButton(
                    onClick = { context.stopService(Intent(context, IslandOverlayService::class.java)); enabled = false },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Остановить островок") }

                Text("Модули следующего этапа", color = Color.White, fontWeight = FontWeight.SemiBold)
                ModuleRow(Icons.Rounded.MusicNote, "Музыкальный плеер", "Интеграция MediaSession")
                ModuleRow(Icons.Rounded.Message, "SMS и уведомления", "Через доступные системные уведомления")
                ModuleRow(Icons.Rounded.Call, "Звонки", "Системные статусы и уведомления")
                ModuleRow(Icons.Rounded.Timer, "Таймер", "Обратный отсчёт")
                ModuleRow(Icons.Rounded.Mic, "Диктофон", "Запись с разрешением микрофона")

                Text(
                    "Прототип 0.1.0 • Android 8.0+ • Galaxy S25 и другие устройства",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun SettingSlider(title: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, onChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, modifier = Modifier.weight(1f))
            Text("${value.toInt()} $unit", color = Color(0xFF9BE7C1))
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun ModuleRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF181B1D), RoundedCornerShape(14.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color(0xFF9BE7C1))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}
