package com.example.dynamicislandpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.drawable.GradientDrawable

class IslandOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var islandView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val width = intent?.getFloatExtra(EXTRA_WIDTH, 190f)?.toInt() ?: 190
        val height = intent?.getFloatExtra(EXTRA_HEIGHT, 42f)?.toInt() ?: 42
        val radius = intent?.getFloatExtra(EXTRA_RADIUS, 28f) ?: 28f
        showIsland(width, height, radius)
        return START_STICKY
    }

    private fun showIsland(width: Int, height: Int, radius: Float) {
        if (islandView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "♪     Dynamic Island"
            textSize = 13f
            setTextColor(AndroidColor.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val bg = GradientDrawable().apply {
                setColor(AndroidColor.BLACK)
                cornerRadius = radius * resources.displayMetrics.density
            }
            background = bg
            elevation = 12f
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            (width * resources.displayMetrics.density).toInt(),
            (height * resources.displayMetrics.density).toInt(),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (8 * resources.displayMetrics.density).toInt()
        }
        windowManager?.addView(view, params)
        islandView = view
    }

    override fun onDestroy() {
        islandView?.let { runCatching { windowManager?.removeView(it) } }
        islandView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Dynamic Island", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Dynamic Island Pro")
            .setContentText("Интерактивный островок активен")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.example.dynamicislandpro.START"
        const val ACTION_STOP = "com.example.dynamicislandpro.STOP"
        const val EXTRA_WIDTH = "width"
        const val EXTRA_HEIGHT = "height"
        const val EXTRA_RADIUS = "radius"
        private const val CHANNEL_ID = "dynamic_island_service"
        private const val NOTIFICATION_ID = 1001
    }
}
