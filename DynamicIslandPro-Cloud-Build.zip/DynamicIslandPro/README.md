# Dynamic Island Pro — starter project

Android Studio project, Kotlin + Jetpack Compose.

## Target devices
- Minimum Android: 8.0 (API 26)
- Compile/target SDK: 35
- Tested build: not yet performed in this environment
- Primary target: Samsung Galaxy S25

## Open and build
1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Connect the phone with USB debugging enabled, or use an emulator.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

APK output is normally under `app/build/outputs/apk/debug/`.

## Current prototype
- Compose settings screen.
- Live preview for island width, height and corner radius.
- Overlay permission handoff.
- Foreground service that displays a simple overlay pill.

## Not implemented yet
Music controls, SMS content/actions, call controls, timer, voice recording,
gesture handling, persistent preferences, and production-grade animation.

## Important Android limitations
- Overlay permission must be granted by the user in system settings.
- Notification access is a separate special access setting.
- SMS and call access are restricted by Android and Google Play policy.
  The intended implementation should use permitted notifications / public APIs
  and must not silently read or send messages or place/answer calls.
- Microphone recording requires runtime permission and a visible foreground
  service with the correct microphone service type.
- Android 14+ foreground-service rules and OEM background restrictions need
  device testing, especially on Samsung One UI.

This is a development starter, not a release-ready APK.
